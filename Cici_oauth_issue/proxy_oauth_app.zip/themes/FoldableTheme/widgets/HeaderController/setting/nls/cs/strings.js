define({
  "group": "Název",
  "openAll": "Otevřít vše na jednom panelu",
  "dropDown": "Zobrazit v rozbalovací nabídce",
  "noGroup": "Není nastavena žádná skupina widgetů.",
  "groupSetLabel": "Nastavit vlastnosti skupin widgetů"
});