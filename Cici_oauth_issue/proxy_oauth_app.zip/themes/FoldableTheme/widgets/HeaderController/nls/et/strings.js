define({
  "_widgetLabel": "Päise kontroller",
  "signin": "Logi sisse",
  "signout": "Logi välja",
  "about": "Info",
  "signInTo": "Logi sisse",
  "cantSignOutTip": "See funktsioon pole eelvaaterežiimis rakendatav.",
  "more": "rohkem"
});